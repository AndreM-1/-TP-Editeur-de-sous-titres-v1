Pr�-requis avant de lancer l'application :

- Pour la base de donn�es, j'ai utilis� PostgreSQL. Il faudrait donc cr�er une base de donn�es sous PostgreSQL qui se nomme "JavaEE_Editeur_sous_titres" en localhost avec Port=5432, login=postgres et mot de passe=admin
- Il faudrait cr�er sous la racine le r�pertoire : "C:\fichiersTempEditeurSousTitres" pour stocker les fichiers temporaires lors de l'upload des fichiers de sous-titres.
- Une fois l'application lanc�e sous Eclipse, il faut copier l'URL sur un vrai navigateur pour que l'affichage soit correct, car sur le navigateur d'Eclipse, cela ne sera pas le cas.